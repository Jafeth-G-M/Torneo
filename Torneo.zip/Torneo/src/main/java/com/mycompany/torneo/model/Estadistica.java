/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.torneo.model;

/**
 *
 * @author jafet
 */
public class Estadistica {
    
    private Equipo equipo;
    private int partidosJugados;
    private int partidosGanados;
    private int partidosPerdidos;
    private int goles;

    public Equipo getEquipo() {
        return equipo;
    }

    public int getPartidosJugados() {
        return partidosJugados;
    }

    public int getPartidosGanados() {
        return partidosGanados;
    }

    public int getPartidosPerdidos() {
        return partidosPerdidos;
    }

    public int getGoles() {
        return goles;
    }

    public void setEquipo(Equipo equipo) {
        this.equipo = equipo;
    }

    public void setPartidosJugados(int partidosJugados) {
        this.partidosJugados = partidosJugados;
    }

    public void setPartidosGanados(int partidosGanados) {
        this.partidosGanados = partidosGanados;
    }

    public void setPartidosPerdidos(int partidosPerdidos) {
        this.partidosPerdidos = partidosPerdidos;
    }

    public void setGoles(int goles) {
        this.goles = goles;
    }

    public Estadistica() {
    }

    public Estadistica(Equipo equipo, int partidosJugados, int partidosGanados, int partidosPerdidos, int goles) {
        this.equipo = equipo;
        this.partidosJugados = partidosJugados;
        this.partidosGanados = partidosGanados;
        this.partidosPerdidos = partidosPerdidos;
        this.goles = goles;
    }

    
}
