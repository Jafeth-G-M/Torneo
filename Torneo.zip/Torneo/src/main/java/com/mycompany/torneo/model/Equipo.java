/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.torneo.model;

/**
 *
 * @author jafet
 */
public class Equipo {
    private String nombre;
    private String fotoArchivo;
    private String fotoCamara;
    private Deporte deporte; 

    public String getNombre() {
        return nombre;
    }

    public String getFotoArchivo() {
        return fotoArchivo;
    }

    public String getFotoCamara() {
        return fotoCamara;
    }

    public Deporte getDeporte() {
        return deporte;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setFotoArchivo(String fotoArchivo) {
        this.fotoArchivo = fotoArchivo;
    }

    public void setFotoCamara(String fotoCamara) {
        this.fotoCamara = fotoCamara;
    }

    public void setDeporte(Deporte deporte) {
        this.deporte = deporte;
    }

    public Equipo() {
    }

    public Equipo(String nombre, String fotoArchivo, String fotoCamara, Deporte deporte) {
        this.nombre = nombre;
        this.fotoArchivo = fotoArchivo;
        this.fotoCamara = fotoCamara;
        this.deporte = deporte;
    }
    
    
}
