/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.torneo.model;

/**
 *
 * @author jafet
 */

import java.util.List;

public class Torneo {
    private String nombre;
    private Deporte deporte;
    private int cantidadEquipos;
    private int tiempoPorPartido;
    private List<Equipo> equipos;

    public String getNombre() {
        return nombre;
    }

    public Deporte getDeporte() {
        return deporte;
    }

    public int getCantidadEquipos() {
        return cantidadEquipos;
    }

    public int getTiempoPorPartido() {
        return tiempoPorPartido;
    }

    public List<Equipo> getEquipos() {
        return equipos;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDeporte(Deporte deporte) {
        this.deporte = deporte;
    }

    public void setCantidadEquipos(int cantidadEquipos) {
        this.cantidadEquipos = cantidadEquipos;
    }

    public void setTiempoPorPartido(int tiempoPorPartido) {
        this.tiempoPorPartido = tiempoPorPartido;
    }

    public void setEquipos(List<Equipo> equipos) {
        this.equipos = equipos;
    }

    public Torneo(String nombre, Deporte deporte, int cantidadEquipos, int tiempoPorPartido, List<Equipo> equipos) {
        this.nombre = nombre;
        this.deporte = deporte;
        this.cantidadEquipos = cantidadEquipos;
        this.tiempoPorPartido = tiempoPorPartido;
        this.equipos = equipos;
    }

    public Torneo() {
    }
    
    
}
