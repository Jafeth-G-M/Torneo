/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.torneo.model;

/**
 *
 * @author jafet
 */

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Ranking {
    private List<Estadistica> estadisticas;

    public Ranking(List<Estadistica> estadisticas) {
        this.estadisticas = estadisticas;
    }

    public List<Estadistica> getEstadisticas() {
        return estadisticas;
    }

    public void ordenarPorPuntaje() {
        Collections.sort(estadisticas, new Comparator<Estadistica>() {
            @Override
            public int compare(Estadistica e1, Estadistica e2) {
                int puntos1 = e1.getPartidosGanados() * 3 + (e1.getPartidosJugados() - e1.getPartidosGanados() - e1.getPartidosPerdidos()) * 2;
                int puntos2 = e2.getPartidosGanados() * 3 + (e2.getPartidosJugados() - e2.getPartidosGanados() - e2.getPartidosPerdidos()) * 2;
                return Integer.compare(puntos2, puntos1); // Orden descendente
            }
        });
    }
}